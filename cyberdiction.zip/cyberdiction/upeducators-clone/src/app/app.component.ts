import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Event,NavigationEnd, Router, RouterOutlet } from '@angular/router';
import * as AOS from 'aos';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})

export class AppComponent implements OnInit, AfterViewInit {
   title = 'upeducators-clone';
  isSignInPage = false;

  constructor(private router: Router) {
    this.router.events.subscribe((event: Event) => {
      if (event instanceof NavigationEnd) {
        this.isSignInPage = event.urlAfterRedirects.includes('/signin');
        // Refresh AOS after navigation
        setTimeout(() => {
          AOS.refresh();
        }, 100);
      }
    });
  }

  ngOnInit() {
    AOS.init({
      duration: 1200,
      easing: 'ease-in-out',
      once: false, // This allows animations to happen every time element comes into view
      mirror: true // Whether elements should animate out while scrolling past them
    });
  }

  ngAfterViewInit() {
    setTimeout(() => {
      AOS.refresh();
    }, 500);
  }

  handleSignIn(): void {
    console.log('Sign in clicked');
    this.router.navigate(['/signin']);
  }
}