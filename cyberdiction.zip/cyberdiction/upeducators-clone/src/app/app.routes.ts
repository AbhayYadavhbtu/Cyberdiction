import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { CoursesComponent } from './pages/courses/courses.component';
import { EventsComponent } from './pages/events/events.component';
import { ContactComponent } from './pages/contact/contact.component';
import { SigninComponent } from './pages/signin/signin.component';
import { EnrollComponent } from './pages/enroll/enroll.component';
import { AboutComponent } from './pages/about/about.component';
import { GalleryPageComponent } from './pages/gallery-page/gallery-page.component';
import { CourseDetailComponent } from './components/course-detail/course-detail.component';
// If you have a NotFoundComponent, import it. Otherwise, create a simple one.


export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'about', component: AboutComponent},
  { path: 'gallery', component: GalleryPageComponent},
  { path: 'courses', component: CoursesComponent },
   { path: 'course/:id', component: CourseDetailComponent },
  { path: 'events', component: EventsComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'signin', component: SigninComponent },
  { path: 'enroll', component: EnrollComponent },
//   { path: '**', component: NotFoundComponent }
];
