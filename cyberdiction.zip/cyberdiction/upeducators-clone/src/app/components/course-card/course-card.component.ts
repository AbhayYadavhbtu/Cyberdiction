// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-course-card',
//   imports: [],
//   templateUrl: './course-card.component.html',
//   styleUrl: './course-card.component.css'
// })
// export class CourseCardComponent {

// }

import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-course-card',
  standalone: true,
  templateUrl: './course-card.component.html',
  styleUrls: ['./course-card.component.css']
})
export class CourseCardComponent {
  @Input() title: string = '';
  @Input() img: string = '';
}
