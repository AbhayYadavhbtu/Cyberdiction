

import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-course-card',
  standalone: true,
   imports: [CommonModule, RouterModule],
  templateUrl: './course-card.component.html',
  styleUrls: ['./course-card.component.css']
})
export class CourseCardComponent {
   @Input() id!: number;
  @Input() title: string = '';
  @Input() img: string = '';
  @Input() cost!:number;

  constructor(private router: Router) {}

  viewDetails() {
    this.router.navigate(['/course', this.id]);
  }
}
