import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { CourseService } from '../../services/course.service';
import { NavbarComponent } from '../navbar/navbar.component';
import { FooterComponent } from '../footer/footer.component';


@Component({
  selector: 'app-course-detail',
  imports: [CommonModule, RouterModule,NavbarComponent,FooterComponent],
  templateUrl: './course-detail.component.html',
  styleUrl: './course-detail.component.css'
})
export class CourseDetailComponent {
   course: any;

  constructor(private route: ActivatedRoute, private courseService: CourseService) {}

  ngOnInit(): void {

    this.route.params.subscribe(params => {
      const id = +params['id']; // get route param as number
      this.fetchCourse(id);
    
   
  });
}

     fetchCourse(id: number): void {
     this.courseService.getCourseById(id).subscribe({
      next: (data) => {
        this.course = data;
      },
      error: (err) => {
        console.error('Error fetching course:', err);
      }
    });
  }
  

}
