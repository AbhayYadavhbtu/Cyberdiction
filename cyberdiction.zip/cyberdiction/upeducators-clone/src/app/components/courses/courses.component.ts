import { Component } from '@angular/core';
import { CourseCardComponent } from '../course-card/course-card.component';
import { CourseDTO, CourseService } from '../../services/course.service';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-courses',
  imports: [CourseCardComponent,CommonModule],
  templateUrl: './courses.component.html',
  styleUrl: './courses.component.css'
})
export class CoursesComponent {
  educatorCourses: CourseDTO[] = [];
  studentCourses: CourseDTO[] = [];
  professionalCourses: CourseDTO[] = [];

  constructor(private courseService: CourseService) {}

  ngOnInit(): void {
    this.courseService.getAllEducatorCourses().subscribe(data => this.educatorCourses = data);
    this.courseService.getAllStudentCourses().subscribe(data => this.studentCourses = data);
    this.courseService.getAllProfessionalCourses().subscribe(data => this.professionalCourses = data);
  }

}
