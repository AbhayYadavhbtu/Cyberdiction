import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-gallery',
  imports: [FormsModule,CommonModule],
  templateUrl: './gallery.component.html',
  styleUrl: './gallery.component.css'
})
export class GalleryComponent {
  activeModalIndex: number | null = null;
  
  cards = [
    {
      image: 'https://picsum.photos/id/1015/600/400.jpg',
      title: 'Mountain View',
      description: 'Beautiful mountain landscape with clouds',
      galleryImages: [
        { large: 'https://picsum.photos/id/1015/600/400.jpg', thumb: 'https://picsum.photos/id/1015/150/100.jpg', alt: 'Mountain' },
        { large: 'https://picsum.photos/id/1039/600/400.jpg', thumb: 'https://picsum.photos/id/1039/150/100.jpg', alt: 'Forest' }
        
      ]
    },
    {
      image: 'https://picsum.photos/id/1039/600/400.jpg',
      title: 'Forest Path',
      description: 'Sunny path through dense forest',
      galleryImages: [
        { large: 'https://picsum.photos/id/1039/600/400.jpg', thumb: 'https://picsum.photos/id/1039/150/100.jpg', alt: 'Forest' },
        { large: 'https://picsum.photos/id/1015/600/400.jpg', thumb: 'https://picsum.photos/id/1015/150/100.jpg', alt: 'Mountain' }
      ]
    },
    {
      image: 'https:www.cyberdictiontechnology.com/images/photos/member-03.jpg',
      title: 'IT EVENTS',
      description: 'Introduction to Latest technologies basic to advanced',
      galleryImages: [
        { large:'https:www.cyberdictiontechnology.com/images/photos/member-03.jpg', thumb:'https://www.cyberdictiontechnology.com/images/photos/member-03.jpg', alt: 'Forest' },
        { large: 'https://picsum.photos/id/1039/600/400.jpg', thumb: 'https://picsum.photos/id/1039/150/100.jpg', alt: 'Forest' },
        { large: 'https://picsum.photos/id/1015/600/400.jpg', thumb: 'https://picsum.photos/id/1015/150/100.jpg', alt: 'Mountain' }
      ]
    },
    {
      image: 'https:www.cyberdictiontechnology.com/images/photos/member-03.jpg',
      title: 'IT EVENTS',
      description: 'Introduction to Latest technologies basic to advanced',
      galleryImages: [
        { large:'https:www.cyberdictiontechnology.com/images/photos/member-03.jpg', thumb:'https://www.cyberdictiontechnology.com/images/photos/member-03.jpg', alt: 'Forest' },
        { large: 'https://picsum.photos/id/1039/600/400.jpg', thumb: 'https://picsum.photos/id/1039/150/100.jpg', alt: 'Forest' },
        { large: 'https://picsum.photos/id/1015/600/400.jpg', thumb: 'https://picsum.photos/id/1015/150/100.jpg', alt: 'Mountain' }
      ]
    },
    {
      image: 'https:www.cyberdictiontechnology.com/images/photos/member-03.jpg',
      title: 'IT EVENTS',
      description: 'Introduction to Latest technologies basic to advanced',
      galleryImages: [
        { large:'https:www.cyberdictiontechnology.com/images/photos/member-03.jpg', thumb:'https://www.cyberdictiontechnology.com/images/photos/member-03.jpg', alt: 'Forest' },
        { large: 'https://picsum.photos/id/1039/600/400.jpg', thumb: 'https://picsum.photos/id/1039/150/100.jpg', alt: 'Forest' },
        { large: 'https://picsum.photos/id/1015/600/400.jpg', thumb: 'https://picsum.photos/id/1015/150/100.jpg', alt: 'Mountain' }
      ]
    },
    {
      image: 'https:www.cyberdictiontechnology.com/images/photos/member-03.jpg',
      title: 'IT EVENTS',
      description: 'Introduction to Latest technologies basic to advanced',
      galleryImages: [
        { large:'https:www.cyberdictiontechnology.com/images/photos/member-03.jpg', thumb:'https://www.cyberdictiontechnology.com/images/photos/member-03.jpg', alt: 'Forest' },
        { large: 'https://picsum.photos/id/1039/600/400.jpg', thumb: 'https://picsum.photos/id/1039/150/100.jpg', alt: 'Forest' },
        { large: 'https://picsum.photos/id/1015/600/400.jpg', thumb: 'https://picsum.photos/id/1015/150/100.jpg', alt: 'Mountain' }
      ]
    },
    {
      image: 'https:www.cyberdictiontechnology.com/images/photos/member-03.jpg',
      title: 'IT EVENTS',
      description: 'Introduction to Latest technologies basic to advanced',
      galleryImages: [
        { large:'https:www.cyberdictiontechnology.com/images/photos/member-03.jpg', thumb:'https://www.cyberdictiontechnology.com/images/photos/member-03.jpg', alt: 'Forest' },
        { large: 'https://picsum.photos/id/1039/600/400.jpg', thumb: 'https://picsum.photos/id/1039/150/100.jpg', alt: 'Forest' },
        { large: 'https://picsum.photos/id/1015/600/400.jpg', thumb: 'https://picsum.photos/id/1015/150/100.jpg', alt: 'Mountain' }
      ]
    },
    {
      image: 'https://picsum.photos/id/1015/600/400.jpg',
      title: 'Mountain View',
      description: 'Beautiful mountain landscape with clouds',
      galleryImages: [
        { large: 'https://picsum.photos/id/1015/600/400.jpg', thumb: 'https://picsum.photos/id/1015/150/100.jpg', alt: 'Mountain' },
        { large: 'https://picsum.photos/id/1039/600/400.jpg', thumb: 'https://picsum.photos/id/1039/150/100.jpg', alt: 'Forest' }
        
      ]
    }
  ];

  openModal(index: number) {
    this.activeModalIndex = index;
    document.body.style.overflow = 'hidden';
  }

  closeModal() {
    this.activeModalIndex = null;
    document.body.style.overflow = 'auto';
  }
}
