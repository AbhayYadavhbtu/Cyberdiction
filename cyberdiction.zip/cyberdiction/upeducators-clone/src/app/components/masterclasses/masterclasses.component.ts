import { Component } from '@angular/core';

@Component({
  selector: 'app-masterclasses',
  imports: [],
  templateUrl: './masterclasses.component.html',
  styleUrl: './masterclasses.component.css'
})
export class MasterclassesComponent {

}
