import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CourseDTO, CourseService } from '../../services/course.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-navbar',
  imports: [RouterLink,FormsModule,CommonModule],
  schemas:[CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent {
  selectedCourses: CourseDTO[] = [];
  showMainDropdown = false;

  constructor(private courseService: CourseService) {}

  toggleMainDropdown() {
    debugger;
    this.showMainDropdown = !this.showMainDropdown;
    this.selectedCourses = []; // clear sub-dropdown when toggling
  }

  loadCourses(category: string, event: Event) {
    event.preventDefault(); // prevent link default behavior

    this.courseService.getCoursesByCategory(category).subscribe({
      next: (courses) => {
        this.selectedCourses = courses;
      },
      error: (err) => {
        console.error('Error loading courses:', err);
        this.selectedCourses = [];
      }
    });
  }

  hideDropdown() {
    this.showMainDropdown = false;
    this.selectedCourses = [];
  }
}
