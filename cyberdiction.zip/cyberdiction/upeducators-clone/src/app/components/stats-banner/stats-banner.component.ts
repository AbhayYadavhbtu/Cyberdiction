import { Component } from '@angular/core';

@Component({
  selector: 'app-stats-banner',
  imports: [],
  templateUrl: './stats-banner.component.html',
  styleUrl: './stats-banner.component.css'
})
export class StatsBannerComponent {

}
