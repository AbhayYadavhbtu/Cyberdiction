import { AfterViewInit, Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
declare var $: any;

@Component({
  selector: 'app-testimonials',
  imports: [],
   schemas:[CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './testimonials.component.html',
  styleUrl: './testimonials.component.css'
})

export class TestimonialsComponent implements AfterViewInit {
  ngAfterViewInit(): void {
   
    $('#testimonial-slider').owlCarousel({
  items: 1,
  loop: true,
  margin: 10,
  nav: true,  // Ensure navigation is enabled
   transitionStyle: "goDown",
  dots: false,
  responsive: {
    0: {
      items: 1
    },
    768: {
      items: 1
    },
    1000: {
      items: 1
    }
  }
});
  }
}
