import { Component } from '@angular/core';

@Component({
  selector: 'app-video-reviews',
  imports: [],
  templateUrl: './video-reviews.component.html',
  styleUrl: './video-reviews.component.css'
})
export class VideoReviewsComponent {

}
