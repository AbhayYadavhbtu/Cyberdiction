import { Component } from '@angular/core';
import { GalleryComponent } from '../../components/gallery/gallery.component';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { FooterComponent } from '../../components/footer/footer.component';

@Component({
  selector: 'app-gallery-page',
  imports: [GalleryComponent,NavbarComponent,FooterComponent],
  templateUrl: './gallery-page.component.html',
  styleUrl: './gallery-page.component.css'
})
export class GalleryPageComponent {

}
