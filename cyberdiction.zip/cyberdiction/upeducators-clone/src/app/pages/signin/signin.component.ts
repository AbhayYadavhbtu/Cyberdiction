import { Component } from '@angular/core';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { FooterComponent } from '../../components/footer/footer.component';
import { HeroSectionComponent } from '../../components/hero-section/hero-section.component';
import { StatsBannerComponent } from '../../components/stats-banner/stats-banner.component';
import { PartnersComponent } from '../../components/partners/partners.component';
import { CoursesComponent } from '../courses/courses.component';
import { MasterclassesComponent } from '../../components/masterclasses/masterclasses.component';
import { TestimonialsComponent } from '../../components/testimonials/testimonials.component';
import { VideoReviewsComponent } from '../../components/video-reviews/video-reviews.component';
import { FeedbackComponent } from '../../components/feedback/feedback.component';
import { PostsComponent } from '../../components/posts/posts.component';
import { CourseCardComponent } from '../../components/course-card/course-card.component';

@Component({
  selector: 'app-signin',
  imports: [NavbarComponent,FooterComponent,HeroSectionComponent,StatsBannerComponent,PartnersComponent,CoursesComponent,MasterclassesComponent,TestimonialsComponent,VideoReviewsComponent,FeedbackComponent,PostsComponent,CourseCardComponent],
  templateUrl: './signin.component.html',
  styleUrl: './signin.component.css'
})
export class SigninComponent {

}
