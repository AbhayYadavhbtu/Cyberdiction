import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';

export interface CourseDTO {
  courseId: number;
  userId: number;
  instructorName: string;
  courseName: string;
  photos: string[];
  description: string;
  skills: string[];
  curriculum: string[];
  trainingDetails: string;
  price: number;
  createdAt: string;
  category: string;
}


@Injectable({
  providedIn: 'root'
})
export class CourseService {

  private baseUrl = 'http://localhost:8080/course';

  constructor(private http: HttpClient) {}

  getAllEducatorCourses(): Observable<CourseDTO[]> {
    return this.http.get<any>(`${this.baseUrl}/getAll/educator`).pipe(
      map(response => response.data) 
    );
  }

  getAllStudentCourses(): Observable<CourseDTO[]> {
    return this.http.get<any>(`${this.baseUrl}/getAll/student`).pipe(
      map(response => response.data)
    );
  }

  getAllProfessionalCourses(): Observable<CourseDTO[]> {
    return this.http.get<any>(`${this.baseUrl}/getAll/professional`).pipe(
      map(response => response.data)
    );
  }

  getCourseById(id: number): Observable<CourseDTO> {
    return this.http.get<any>(`${this.baseUrl}/get/${id}`).pipe(
   
      map(response => response.data) 
    );
  }
 
 getCoursesByCategory(category: string): Observable<CourseDTO[]> {
  return this.http.get<{ data: CourseDTO[] }>(`${this.baseUrl}/getAll/${category}`)
    .pipe(map(res => res.data));
}

}
